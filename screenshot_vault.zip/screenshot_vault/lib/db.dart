import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import 'classifier.dart';

class Shot {
  final String id;
  final String path;
  final String title;
  final String category;
  final String text;
  final int created; // millisecondsSinceEpoch
  final bool fav;

  const Shot({
    required this.id,
    required this.path,
    required this.title,
    required this.category,
    required this.text,
    required this.created,
    this.fav = false,
  });

  factory Shot.fromMap(Map<String, Object?> m) => Shot(
        id: m['id'] as String,
        path: m['path'] as String,
        title: m['title'] as String,
        category: m['category'] as String,
        text: m['text'] as String,
        created: m['created'] as int,
        fav: (m['fav'] as int) == 1,
      );
}

/// SQLite storage with FTS4 full-text search over title + OCR text.
class Db {
  Db._();
  static final Db instance = Db._();

  Database? _db;
  Future<Database> get _database async => _db ??= await _open();

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    return openDatabase(
      p.join(dir, 'vault.db'),
      version: 2,
      // v2: better classifier and titles. Re-run them on the OCR text that is
      // already stored, so the screenshots do not need to be scanned again.
      onUpgrade: (d, oldVersion, newVersion) async {
        if (oldVersion < 2) await _reclassifyAll(d);
      },
      onCreate: (d, _) async {
        await d.execute('''
          CREATE TABLE shots(
            id TEXT NOT NULL UNIQUE,
            path TEXT NOT NULL,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            text TEXT NOT NULL,
            created INTEGER NOT NULL,
            fav INTEGER NOT NULL DEFAULT 0
          )''');
        await d.execute('CREATE INDEX idx_cat ON shots(category, created DESC)');
        await d.execute(
            'CREATE VIRTUAL TABLE shots_fts USING fts4(title, text, tokenize=unicode61)');
      },
    );
  }

  Future<void> _reclassifyAll(Database d) async {
    final rows = await d.rawQuery('SELECT rowid AS rid, text, created FROM shots');
    const chunk = 500;
    for (var i = 0; i < rows.length; i += chunk) {
      final end = i + chunk > rows.length ? rows.length : i + chunk;
      final batch = d.batch();
      for (final r in rows.sublist(i, end)) {
        final text = r['text'] as String;
        final created = DateTime.fromMillisecondsSinceEpoch(r['created'] as int);
        final category = classify(text);
        final title = buildTitle(text, category, created);
        final rid = r['rid'] as int;
        batch.rawUpdate(
            'UPDATE shots SET category = ?, title = ? WHERE rowid = ?',
            [category, title, rid]);
        batch.rawUpdate(
            'UPDATE shots_fts SET title = ? WHERE docid = ?', [title, rid]);
      }
      await batch.commit(noResult: true);
    }
  }

  Future<bool> has(String id) async {
    final d = await _database;
    final r = await d.rawQuery('SELECT 1 FROM shots WHERE id = ? LIMIT 1', [id]);
    return r.isNotEmpty;
  }

  Future<void> insert(Shot s) async {
    final d = await _database;
    await d.transaction((txn) async {
      final rowId = await txn.insert('shots', {
        'id': s.id,
        'path': s.path,
        'title': s.title,
        'category': s.category,
        'text': s.text,
        'created': s.created,
        'fav': s.fav ? 1 : 0,
      });
      await txn.insert('shots_fts', {
        'docid': rowId,
        'title': s.title,
        'text': s.text,
      });
    });
  }

  /// Turns "blue snea" into `blue* snea*` (all words must match, prefix search).
  String? _ftsQuery(String q) {
    final words = q
        .split(RegExp(r'\s+'))
        .map((w) => w.replaceAll(RegExp(r'[^\p{L}\p{N}]', unicode: true), ''))
        .where((w) => w.isNotEmpty)
        .toList();
    if (words.isEmpty) return null;
    return words.map((w) => '$w*').join(' ');
  }

  Future<List<Shot>> query({
    String search = '',
    String? category,
    bool favOnly = false,
  }) async {
    final d = await _database;
    final where = <String>[];
    final args = <Object?>[];
    final fts = _ftsQuery(search);

    var sql = 'SELECT s.* FROM shots s';
    if (fts != null) {
      sql += ' JOIN shots_fts f ON f.docid = s.rowid';
      where.add('shots_fts MATCH ?');
      args.add(fts);
    }
    if (category != null) {
      where.add('s.category = ?');
      args.add(category);
    }
    if (favOnly) where.add('s.fav = 1');
    if (where.isNotEmpty) sql += ' WHERE ${where.join(' AND ')}';
    sql += ' ORDER BY s.created DESC LIMIT 500';

    final rows = await d.rawQuery(sql, args);
    return rows.map(Shot.fromMap).toList();
  }

  Future<Map<String, int>> categoryCounts() async {
    final d = await _database;
    final rows = await d.rawQuery(
        'SELECT category, COUNT(*) c FROM shots GROUP BY category ORDER BY c DESC');
    return {for (final r in rows) r['category'] as String: r['c'] as int};
  }

  Future<void> setFav(String id, bool fav) async {
    final d = await _database;
    await d.update('shots', {'fav': fav ? 1 : 0}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> setCategory(String id, String category) async {
    final d = await _database;
    await d.update('shots', {'category': category}, where: 'id = ?', whereArgs: [id]);
  }
}
