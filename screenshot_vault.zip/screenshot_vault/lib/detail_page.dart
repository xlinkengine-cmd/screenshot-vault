import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'classifier.dart';
import 'db.dart';

class DetailPage extends StatefulWidget {
  final Shot shot;
  const DetailPage({super.key, required this.shot});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  late bool _fav = widget.shot.fav;
  late String _category = widget.shot.category;

  @override
  Widget build(BuildContext context) {
    final s = widget.shot;
    return Scaffold(
      appBar: AppBar(
        title: Text(s.title, style: const TextStyle(fontSize: 14)),
        actions: [
          IconButton(
            icon: Icon(_fav ? Icons.star : Icons.star_border,
                color: _fav ? Colors.amber : null),
            onPressed: () async {
              setState(() => _fav = !_fav);
              await Db.instance.setFav(s.id, _fav);
            },
          ),
          PopupMenuButton<String>(
            tooltip: 'Move to folder',
            icon: const Icon(Icons.folder_open),
            onSelected: (c) async {
              setState(() => _category = c);
              await Db.instance.setCategory(s.id, c);
            },
            itemBuilder: (_) => [
              for (final c in [
                ...categoryRules.keys,
                noTextCategory,
                fallbackCategory,
              ])
                PopupMenuItem(value: c, child: Text(c)),
            ],
          ),
        ],
      ),
      body: ListView(
        children: [
          InteractiveViewer(
            child: Image.file(File(s.path), fit: BoxFit.contain),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Chip(label: Text('Folder: $_category')),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Text('Text in this screenshot',
                        style: Theme.of(context).textTheme.titleSmall),
                    const Spacer(),
                    TextButton.icon(
                      icon: const Icon(Icons.copy, size: 18),
                      label: const Text('Copy'),
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: s.text));
                        ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Text copied')));
                      },
                    ),
                  ],
                ),
                SelectableText(s.text.isEmpty ? '(no text found)' : s.text),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
