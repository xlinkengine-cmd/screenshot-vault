import 'package:intl/intl.dart';

/// Keyword rules per category. Each keyword found in the OCR text adds 1 point.
/// Easy to extend: add words (including Roman Urdu) or whole new categories.
const Map<String, List<String>> categoryRules = {
  'Recipes': [
    'ingredients', 'recipe', 'tablespoon', 'tbsp', 'teaspoon', 'tsp',
    'preheat', 'bake', 'simmer', 'chopped', 'servings', 'marinate',
  ],
  'Shopping': [
    'add to cart', 'buy now', 'price', 'pkr', 'rs.', 'free delivery',
    'discount', '% off', 'sale', 'in stock', 'checkout', 'size', 'colour',
    'color', 'daraz',
  ],
  'Money': [
    'transaction', 'balance', 'payment', 'paid', 'invoice', 'receipt',
    'total', 'amount', 'account', 'transfer', 'easypaisa', 'jazzcash',
    'iban', 'bill',
  ],
  'Travel': [
    'flight', 'hotel', 'booking', 'check-in', 'airport', 'itinerary',
    'directions', 'boarding', 'reservation', 'tour', 'visa',
  ],
  'Code': [
    'function', 'import ', 'const ', 'class ', 'exception', 'error:',
    'return ', 'github', 'stack overflow', 'npm', 'flutter', 'def ',
  ],
  'Learning': [
    'tutorial', 'how to', 'tips', 'guide', 'learn', 'course', 'step 1',
    'lesson', 'beginner', 'roadmap',
  ],
  'Social': [
    'likes', 'followers', 'following', 'retweet', 'reply', 'comments',
    'views', 'instagram', 'tiktok', 'reels', 'share', 'repost',
  ],
  'Chats': [
    'typing', 'seen', 'delivered', 'whatsapp', 'message', 'online',
    'last seen', 'voice message',
  ],
  'Links': ['http', 'www.', '.com', '.pk', '.org'],
};

const String fallbackCategory = 'Other';

String classify(String text) {
  final t = text.toLowerCase();
  if (t.trim().isEmpty) return fallbackCategory;

  var best = fallbackCategory;
  var bestScore = 1; // need at least 2 matching keywords to win
  categoryRules.forEach((category, words) {
    final score = words.where(t.contains).length;
    if (score > bestScore) {
      best = category;
      bestScore = score;
    }
  });
  return best;
}

/// Example: `2026-11-08_Recipes_Butter-Chicken-Masala`
String buildTitle(String text, String category, DateTime date) {
  final lines = text
      .split('\n')
      .map((l) => l.trim())
      .where((l) => l.length >= 4 && RegExp(r'\p{L}', unicode: true).hasMatch(l))
      .take(6)
      .toList();

  var pick = '';
  for (final l in lines) {
    if (l.length <= 60 && l.length > pick.length) pick = l;
  }
  if (pick.isEmpty && lines.isNotEmpty) pick = lines.first;

  final words = pick
      .replaceAll(RegExp(r'[^\p{L}\p{N}\s]', unicode: true), ' ')
      .split(RegExp(r'\s+'))
      .where((w) => w.isNotEmpty)
      .take(5)
      .map((w) => w[0].toUpperCase() + w.substring(1))
      .toList();

  final slug = words.isEmpty ? 'Screenshot' : words.join('-');
  final day = DateFormat('yyyy-MM-dd').format(date);
  return '${day}_${category}_$slug';
}
