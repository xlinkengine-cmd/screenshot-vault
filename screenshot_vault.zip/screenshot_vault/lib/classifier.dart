import 'package:intl/intl.dart';

/// Keywords for one category.
/// [words] score 1 point each, [strong] words score 2 points each.
/// A category needs at least 2 points to win, so one strong word is enough.
class Rule {
  final List<String> words;
  final List<String> strong;
  const Rule(this.words, [this.strong = const []]);
}

/// Easy to extend: add words (including Roman Urdu) or whole new categories.
const Map<String, Rule> categoryRules = {
  'Recipes': Rule(
    ['tablespoon', 'tbsp', 'teaspoon', 'tsp', 'bake', 'simmer', 'chopped',
      'servings', 'marinate', 'minutes', 'cups'],
    ['ingredients', 'recipe', 'preheat'],
  ),
  'Shopping': Rule(
    ['price', 'pkr', 'rs.', 'discount', '% off', 'sale', 'size', 'colour',
      'color', 'delivery', 'order', 'cart'],
    ['add to cart', 'buy now', 'free delivery', 'in stock', 'checkout', 'daraz'],
  ),
  'Money': Rule(
    ['payment', 'paid', 'total', 'amount', 'account', 'transfer', 'bill',
      'bank', 'rupees'],
    ['transaction', 'balance', 'invoice', 'receipt', 'easypaisa', 'jazzcash',
      'iban'],
  ),
  'Travel': Rule(
    ['booking', 'airport', 'directions', 'reservation', 'tour', 'visa',
      'trip', 'map'],
    ['flight', 'hotel', 'check-in', 'itinerary', 'boarding pass'],
  ),
  'Code': Rule(
    ['import ', 'const ', 'class ', 'return ', 'def ', 'npm', 'commit',
      'repository', 'build'],
    ['github', 'stack overflow', 'exception', 'function', 'flutter',
      'error:', 'workflow'],
  ),
  'Learning': Rule(
    ['tips', 'guide', 'learn', 'step 1', 'beginner', 'how to'],
    ['tutorial', 'course', 'roadmap', 'lesson'],
  ),
  'Social': Rule(
    ['reply', 'comments', 'views', 'share', 'repost', 'follow'],
    ['followers', 'following', 'retweet', 'instagram', 'tiktok', 'reels',
      'likes', 'view all', 'liked by', 'facebook'],
  ),
  'Chats': Rule(
    ['typing', 'seen', 'message', 'online'],
    ['whatsapp', 'last seen', 'voice message', 'delivered'],
  ),
  'News': Rule(
    ['breaking', 'reported', 'minister', 'government', 'police', 'court',
      'election', 'according to'],
    ['news', 'headlines'],
  ),
  'Health': Rule(
    ['doctor', 'symptoms', 'calories', 'workout', 'diet', 'protein',
      'exercise', 'sleep', 'vitamin'],
    ['health', 'medicine', 'treatment'],
  ),
  'Links': Rule(['.com', '.pk', '.org'], ['http', 'www.']),
};

/// Screenshots with almost no readable text: photos, memes, reels, art.
const String noTextCategory = 'Images';
const String fallbackCategory = 'Other';

String classify(String text) {
  final t = text.toLowerCase().trim();
  if (t.length < 20) return noTextCategory;

  var best = fallbackCategory;
  var bestScore = 1; // a category needs a score of at least 2
  categoryRules.forEach((category, rule) {
    var score = 0;
    for (final w in rule.words) {
      if (t.contains(w)) score += 1;
    }
    for (final w in rule.strong) {
      if (t.contains(w)) score += 2;
    }
    if (score > bestScore) {
      best = category;
      bestScore = score;
    }
  });
  return best;
}

final _timeRe = RegExp(r'\b\d{1,2}:\d{2}\b');
final _wordRe = RegExp(r'\p{L}{3,}', unicode: true);
final _letterRe = RegExp(r'\p{L}', unicode: true);
final _symbolRe = RegExp(r'[^\p{L}\p{N}\s]', unicode: true);

/// Picks the most title-like line of the screenshot, ignoring the status bar
/// (clock, battery) and lines that are mostly symbols or digits.
String _bestLine(String text) {
  final lines = text
      .split('\n')
      .map((l) => l.trim())
      .where((l) => l.isNotEmpty)
      .take(15)
      .toList();

  var best = '';
  var bestScore = 0;
  for (var i = 0; i < lines.length; i++) {
    final l = lines[i];
    if (_timeRe.hasMatch(l) && l.length < 45) continue; // status bar line
    final words = _wordRe.allMatches(l).length;
    if (words < 2) continue;
    final letters = _letterRe.allMatches(l).length;
    if (letters / l.length < 0.6) continue;

    var score = (words > 6 ? 6 : words) * 10 - i; // earlier lines win ties
    if (l.length > 70) score -= 15;
    if (score > bestScore) {
      best = l;
      bestScore = score;
    }
  }
  return best;
}

/// Example: `2026-11-08_Recipes_Butter-Chicken-Masala`
String buildTitle(String text, String category, DateTime date) {
  final words = _bestLine(text)
      .replaceAll(_symbolRe, ' ')
      .split(RegExp(r'\s+'))
      .where((w) => w.isNotEmpty)
      .take(5)
      .map((w) => w[0].toUpperCase() + w.substring(1))
      .toList();

  var slug = words.join('-');
  if (slug.length > 40) slug = slug.substring(0, 40);
  if (slug.isEmpty) slug = 'Screenshot-${DateFormat('HHmm').format(date)}';

  final day = DateFormat('yyyy-MM-dd').format(date);
  return '${day}_${category}_$slug';
}
