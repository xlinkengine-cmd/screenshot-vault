import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:photo_manager/photo_manager.dart';

import 'classifier.dart';
import 'db.dart';

/// Finds screenshots in the gallery, runs on-device OCR, then classifies,
/// names and stores each one. Already-processed screenshots are skipped.
class Scanner {
  bool _running = false;
  bool get running => _running;

  /// Returns the number of newly added screenshots.
  Future<int> scan({void Function(int done, int total)? onProgress}) async {
    if (_running) return 0;
    _running = true;

    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    var added = 0;

    try {
      final perm = await PhotoManager.requestPermissionExtend();
      if (!perm.hasAccess) {
        throw StateError('Photo access denied. Allow access to all photos.');
      }

      final albums = await PhotoManager.getAssetPathList(
        type: RequestType.image,
        filterOption: FilterOptionGroup(
          orders: [const OrderOption(type: OrderOptionType.createDate, asc: false)],
        ),
      );
      final shotAlbums = albums
          .where((a) => a.name.toLowerCase().contains('screenshot'))
          .toList();

      var total = 0;
      for (final a in shotAlbums) {
        total += await a.assetCountAsync;
      }

      var done = 0;
      for (final album in shotAlbums) {
        final count = await album.assetCountAsync;
        for (var page = 0; page * 50 < count; page++) {
          final assets = await album.getAssetListPaged(page: page, size: 50);
          for (final asset in assets) {
            done++;
            onProgress?.call(done, total);
            if (await Db.instance.has(asset.id)) continue;

            final file = await asset.originFile;
            if (file == null) continue;

            var text = '';
            try {
              final result = await recognizer.processImage(InputImage.fromFile(file));
              text = result.text;
            } catch (_) {
              // Keep going: store it with empty text so it is not retried forever.
            }

            final category = classify(text);
            final created = asset.createDateTime;
            await Db.instance.insert(Shot(
              id: asset.id,
              path: file.path,
              title: buildTitle(text, category, created),
              category: category,
              text: text,
              created: created.millisecondsSinceEpoch,
            ));
            added++;
          }
        }
      }
    } finally {
      await recognizer.close();
      _running = false;
    }
    return added;
  }
}
