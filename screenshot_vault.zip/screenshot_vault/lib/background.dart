import 'package:workmanager/workmanager.dart';

import 'scanner.dart';

const _uniqueName = 'screenshot-scan';
const _taskName = 'screenshotScan';

/// Runs in a background isolate, even when the app is closed.
@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      await Scanner().scan();
      return true;
    } catch (_) {
      return false; // WorkManager will retry later
    }
  });
}

/// Android's minimum interval for periodic work is 15 minutes.
Future<void> initBackground() async {
  await Workmanager().initialize(callbackDispatcher);
  await Workmanager().registerPeriodicTask(
    _uniqueName,
    _taskName,
    frequency: const Duration(minutes: 15),
  );
}
