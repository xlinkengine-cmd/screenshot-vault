import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';

import 'db.dart';
import 'detail_page.dart';
import 'scanner.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final _scanner = Scanner();
  final _searchCtrl = TextEditingController();
  Timer? _debounce;

  List<Shot> _shots = [];
  Map<String, int> _counts = {};
  String? _category; // null = All
  bool _favOnly = false;

  bool _scanning = false;
  int _done = 0;
  int _total = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _reload();
    _scan();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  // Pick up new screenshots whenever the app comes back to the foreground.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _scan();
  }

  Future<void> _scan() async {
    if (_scanning) return;
    setState(() {
      _scanning = true;
      _done = 0;
      _total = 0;
    });
    try {
      await _scanner.scan(onProgress: (d, t) {
        if (!mounted) return;
        // Refresh the list every 10 items so results appear while scanning.
        setState(() {
          _done = d;
          _total = t;
        });
        if (d % 10 == 0) _reload();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(e.toString())));
      }
    }
    if (mounted) setState(() => _scanning = false);
    _reload();
  }

  Future<void> _reload() async {
    final shots = await Db.instance.query(
      search: _searchCtrl.text,
      category: _category,
      favOnly: _favOnly,
    );
    final counts = await Db.instance.categoryCounts();
    if (!mounted) return;
    setState(() {
      _shots = shots;
      _counts = counts;
    });
  }

  void _onSearchChanged(String _) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 250), _reload);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Screenshot Vault'),
        actions: [
          IconButton(
            tooltip: 'Scan for new screenshots',
            onPressed: _scanning ? null : _scan,
            icon: const Icon(Icons.refresh),
          ),
        ],
        bottom: _scanning
            ? PreferredSize(
                preferredSize: const Size.fromHeight(4),
                child: LinearProgressIndicator(
                  value: _total == 0 ? null : _done / _total,
                ),
              )
            : null,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: SearchBar(
              controller: _searchCtrl,
              hintText: 'Search any text inside your screenshots',
              leading: const Icon(Icons.search),
              onChanged: _onSearchChanged,
              trailing: [
                if (_searchCtrl.text.isNotEmpty)
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () {
                      _searchCtrl.clear();
                      _reload();
                    },
                  ),
              ],
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _chip('All', _category == null && !_favOnly, () {
                  _category = null;
                  _favOnly = false;
                  _reload();
                }),
                _chip('★ Favorites', _favOnly, () {
                  _favOnly = !_favOnly;
                  _reload();
                }),
                for (final e in _counts.entries)
                  _chip('${e.key} (${e.value})', _category == e.key, () {
                    _category = _category == e.key ? null : e.key;
                    _reload();
                  }),
              ],
            ),
          ),
          if (_scanning && _total > 0)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Text('Scanning $_done / $_total',
                  style: Theme.of(context).textTheme.bodySmall),
            ),
          Expanded(child: _buildList()),
        ],
      ),
    );
  }

  Widget _chip(String label, bool selected, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
        child: FilterChip(
          label: Text(label),
          selected: selected,
          onSelected: (_) => onTap(),
        ),
      );

  Widget _buildList() {
    if (_shots.isEmpty) {
      return Center(
        child: Text(
          _scanning ? 'Scanning your screenshots…' : 'No screenshots found',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
      );
    }
    return ListView.builder(
      itemCount: _shots.length,
      itemBuilder: (context, i) {
        final s = _shots[i];
        final snippet = s.text.replaceAll('\n', ' ');
        return ListTile(
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(
              File(s.path),
              width: 56,
              height: 56,
              fit: BoxFit.cover,
              cacheWidth: 160,
              errorBuilder: (_, __, ___) =>
                  const SizedBox(width: 56, height: 56, child: Icon(Icons.image_not_supported)),
            ),
          ),
          title: Text(s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(
            snippet.isEmpty ? s.category : snippet,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: s.fav ? const Icon(Icons.star, color: Colors.amber) : null,
          onTap: () async {
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => DetailPage(shot: s)),
            );
            _reload();
          },
        );
      },
    );
  }
}
