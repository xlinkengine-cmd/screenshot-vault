# Screenshot Vault (Android, Flutter)

Scans every screenshot on the phone with on-device OCR, classifies it, gives it a
readable name (`2026-11-08_Recipes_Butter-Chicken-Masala`), files it into a folder,
and makes all the text inside it searchable.

## Setup

Requires the Flutter SDK (https://docs.flutter.dev/get-started/install).

```bash
flutter create --platforms=android --org com.example screenshot_vault_app
cd screenshot_vault_app
flutter pub add sqflite path photo_manager google_mlkit_text_recognition intl workmanager
```

Then copy this project's `lib/` folder over the generated `lib/` folder
(replace `main.dart` and add the other files).

## Android configuration

1. `android/app/build.gradle` (or `build.gradle.kts`): set `minSdk` to **24**
   (ML Kit needs 21+, 24 is a safe choice).

2. `android/app/src/main/AndroidManifest.xml`: add inside `<manifest>`, above `<application>`:

```xml
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"
    android:maxSdkVersion="32"/>
```

3. Run on a real phone (gallery access is limited on emulators):

```bash
flutter run
```

On first launch choose **Allow access to all photos**. If you pick "Selected photos only"
(Android 14+), only those photos get scanned.

## How it works

| File | Job |
|---|---|
| `lib/scanner.dart` | Finds the Screenshots album, runs ML Kit OCR on each new image |
| `lib/classifier.dart` | Keyword scoring into categories + builds the file-style title |
| `lib/db.dart` | SQLite storage with FTS4 full-text search (prefix matching) |
| `lib/home_page.dart` | Search box, folder chips, results list, scan progress |
| `lib/detail_page.dart` | Full image, extracted text, copy, favorite, change folder |

Folders are **virtual** (a category column), so your original files are never moved
or renamed. This avoids the broad storage permission Google Play restricts.

## Known limits of this starter

- ML Kit's offline OCR supports Latin script only. Urdu/Arabic text will not be read
  (English and Roman Urdu work). A cloud vision model can cover other scripts later.
- New screenshots are scanned when the app opens, and in the background about every
  15 minutes (`lib/background.dart`, Android's minimum for periodic work). It is not
  instant. On Xiaomi, Oppo, Vivo and Samsung phones, set the app's battery usage to
  "Unrestricted", otherwise the system may kill background scans.
- `workmanager` changes its API between versions. If `registerPeriodicTask` or
  `initialize` shows a compile error, check the package's README for the current signature.
- Classification is keyword-based (strong words score 2, normal words 1, a category
  needs 2 points). Screenshots with almost no text go to **Images**. Edit
  `categoryRules` in `classifier.dart` to tune it.
- Updating from version 1: the first launch re-classifies and renames every stored
  screenshot from its saved text (no new OCR needed). This takes a few seconds.
- `ci/debug.keystore` is a fixed signing key used only by the cloud build, so each new
  APK can be installed over the previous one. It is not a secret and is for personal use only.

## Next steps

1. Instant detection (right after you take a screenshot) with a native ContentObserver or a WorkManager content-URI trigger, instead of the 15-minute polling
2. AI categorization and smarter titles using a vision LLM API
3. Duplicate detection (perceptual hash)
4. Reminders and a home-screen search widget
