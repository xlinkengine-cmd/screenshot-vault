"""Patches the freshly generated Flutter Android project.

Run from inside the Flutter project folder (the one that contains `android/`).
Fixes applied:
  1. Photo permissions in AndroidManifest.xml
  2. minSdk 24
  3. Release build: R8 shrinking off + ProGuard rules that ignore the unused
     ML Kit script recognizers (Chinese/Japanese/Korean/Devanagari), which
     otherwise cause "R8: Missing classes detected".
"""
import pathlib
import re
import sys

import shutil

app = pathlib.Path("android/app")

# 0. Stable signing key. Without this every cloud build is signed with a new
#    random key and Android refuses to install it over the previous version.
ks_src = pathlib.Path(__file__).resolve().parent / "debug.keystore"
ks_dst = pathlib.Path.home() / ".android" / "debug.keystore"
ks_dst.parent.mkdir(parents=True, exist_ok=True)
shutil.copy(ks_src, ks_dst)
print(f"signing key installed at {ks_dst}")

# 1. Manifest permissions
manifest = app / "src/main/AndroidManifest.xml"
text = manifest.read_text()
perms = (
    '    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>\n'
    '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" '
    'android:maxSdkVersion="32"/>\n'
)
if "READ_MEDIA_IMAGES" not in text:
    text = text.replace("<application", perms + "    <application", 1)
manifest.write_text(text)
print("manifest: permissions ok")

# 2. ProGuard rules file
(app / "proguard-rules.pro").write_text(
    "-dontwarn com.google.mlkit.vision.text.**\n"
    "-dontwarn com.google.android.gms.internal.mlkit_vision_text_**\n"
)
print("proguard-rules.pro written")

# 3. Gradle file (Kotlin DSL or Groovy)
patched = False
for name in ("build.gradle.kts", "build.gradle"):
    g = app / name
    if not g.exists():
        continue
    kts = name.endswith(".kts")
    s = g.read_text()

    s, n_sdk = re.subn(
        r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion",
        "minSdk = 24" if kts else "minSdkVersion 24",
        s,
    )

    if kts:
        extra = (
            "\n            isMinifyEnabled = false"
            "\n            isShrinkResources = false"
            '\n            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), '
            '"proguard-rules.pro")'
        )
    else:
        extra = (
            "\n            minifyEnabled false"
            "\n            shrinkResources false"
            "\n            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), "
            "'proguard-rules.pro'"
        )
    s, n_rel = re.subn(r"(\brelease\s*\{)", lambda m: m.group(1) + extra, s, count=1)
    if n_rel == 0:
        sys.exit(f"ERROR: could not find the release block in {name}")

    g.write_text(s)
    print(f"{name}: minSdk replaced={n_sdk}, release block patched")
    patched = True
    break

if not patched:
    sys.exit("ERROR: no android/app/build.gradle(.kts) found")
